package blackjack

class Player(val playerStrat: Stategy){
	val myStrat = playerStrat
	

}