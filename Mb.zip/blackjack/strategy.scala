package blackjack
abstract class Strategy() {
	def action() = {

	}
	def bet(amount:int) = {

	}
}