package blackjack

object BlackJackSimulation extends App{
	

}