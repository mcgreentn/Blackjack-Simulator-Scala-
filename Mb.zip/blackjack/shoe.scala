package blackjack

class Shoe(val nDeck: Int, val reShufflePercent: Double){
	var cardsInDeck = 52 * nDeck
	val shuffleTrig = reShufflePercent
	var nextCard = 0
	private var currentCardCount = 0
	var cards = new Array[Int](cardsInDeck)
	for(card <- cards){
		card = nextCard
		nextCard++
		if(nextCard == 13){
			nextCard = 0
		}
	}

	def shuffle() = {
		for(i <- 0 to cardsInDeck - 1){
			var index = r.nextInt(cardsInDeck - 1)
			cards(i) = cards(index)
		}
	}
	def dealCard() : Card {
		var cardReturn = cards(currentCardCount)
		cardCurrentCount++
		var percentLeft = ((cardsInDeck-cardCurrentCount)/cardsInDeck) * 100
		if(percentLeft < shuffleTrig){
			shuffle()
			cardCurrentCount = 0
		}
		return cardReturn
	}	
}