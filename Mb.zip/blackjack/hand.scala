package blackjack

class Hand() {
	var cards = new Array[Int](3)
	var index = 0
	def addCard(card:Int) = {
		if(index < cards.size){
			cards(index) = card
			index++
		}
	}
	def value() = {
		var value = 0;
		var sum = 0;
		var isSoft = hardSoft()
		for (card <- cards){
			value = rank(card) + 1
			if(value > 9){
				sum += 10
			}
			else if(value == 1 && isSoft == "SOFT"){
				sum += 11
			}
			else{
				sum += value
			}
		}
		return sum
	}
	def hardSoft() = {
		var sumNoAce;
		for (card <- cards){
			val cardVal = rank(card) + 1
			if(cardVal != 1){
				sum += cardVal
			}
		}
		if(sumNoAce < 11){
			return "SOFT"
		}
		return "HARD"
	}
}